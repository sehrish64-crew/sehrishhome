'use client';
import Dashboard from './dashboard/Dashboard';

export default function HomePage() {
  return <Dashboard />;
}
