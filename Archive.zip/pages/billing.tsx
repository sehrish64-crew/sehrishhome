'use client';

import Bills from '@/components/Billing';

export default function DoctorsPage() {
  return (
    <div>
      <Bills />
    </div>
  );
}
