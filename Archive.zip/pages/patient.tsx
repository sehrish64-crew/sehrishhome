'use client';

import Patients from '@/components/Patient';

export default function Patient() {
  return (
    <div>
      <Patients />
    </div>
  );
}
